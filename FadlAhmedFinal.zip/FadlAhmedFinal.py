import tkinter as tk
from tkinter import messagebox

class PizzaOrderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("QuickSlice Pizza Ordering System")

        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(self.main_frame, text="Welcome to QuickSlice", font=('Helvetica', 16)).pack(pady=20)

        tk.Button(self.main_frame, text="Start Order", command=self.open_order_window).pack()

        tk.Button(self.main_frame, text="Exit", command=self.exit_app).pack(pady=10)

    def open_order_window(self):
        self.clear_frame()

        tk.Label(self.main_frame, text="Customize your pizza", font=('Helvetica', 14)).pack(pady=10)
        
        tk.Label(self.main_frame, text="Choose Size:").pack()
        self.size_var = tk.StringVar()
        sizes = tk.OptionMenu(self.main_frame, self.size_var, "Small", "Medium", "Large")
        self.size_var.set("Medium")
        sizes.pack()

        tk.Label(self.main_frame, text="Select Toppings:").pack()
        self.topping_vars = {}
        for topping in ["Pepperoni", "Mushrooms", "Onions"]:
            var = tk.BooleanVar()
            tk.Checkbutton(self.main_frame, text=topping, variable=var).pack()
            self.topping_vars[topping] = var

        tk.Button(self.main_frame, text="Checkout", command=self.open_checkout_window).pack(pady=10)

        tk.Button(self.main_frame, text="Back", command=self.back_to_main).pack()

    def open_checkout_window(self):
        order_summary = f"Size: {self.size_var.get()}\n"
        order_summary += "Toppings: " + ", ".join([t for t, v in self.topping_vars.items() if v.get()]) + "\n"

        self.clear_frame()
        tk.Label(self.main_frame, text="Review Your Order", font=('Helvetica', 14)).pack(pady=10)
        tk.Label(self.main_frame, text=order_summary).pack()

        tk.Button(self.main_frame, text="Place Order", command=self.place_order).pack(pady=10)

        tk.Button(self.main_frame, text="Back", command=self.open_order_window).pack()

    def place_order(self):
        messagebox.showinfo("Order Placed", "Your order has been placed successfully!")
        self.back_to_main()

    def exit_app(self):
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            self.root.destroy()

    def back_to_main(self):
        self.clear_frame()
        self.main_frame.pack(fill=tk.BOTH, expand=True)

    def clear_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = PizzaOrderApp(root)
    root.mainloop()
